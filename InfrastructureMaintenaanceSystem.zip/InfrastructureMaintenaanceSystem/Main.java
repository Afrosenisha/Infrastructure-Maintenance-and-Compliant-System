import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // MODULE 1
        AuthenticationService auth =
                new AuthenticationService();

        // MODULE 2
        InfrastructureService infrastructureService =
                new InfrastructureService();

        // MODULE 3
        MaintenanceRequestService requestService =
                new MaintenanceRequestService();

        // MODULE 4
        TechnicianService technicianService =
                new TechnicianService();

        // MODULE 5
        MaintenanceTrackingService trackingService =
                new MaintenanceTrackingService();


        while (true) {

            System.out.println("\n======================================");
            System.out.println("   INFRASTRUCTURE MAINTENANCE SYSTEM");
            System.out.println("======================================");

            System.out.println("1. Login");
            System.out.println("2. Register");
            System.out.println("3. Exit");

            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();


            switch (choice) {

                case "1":

                    System.out.print("Username: ");
                    String username = scanner.nextLine();

                    System.out.print("Password: ");
                    String password = scanner.nextLine();

                    try {

                        User loggedInUser =
                                auth.login(username, password);

                        System.out.println("\nLogin successful!");
                        System.out.println(
                                "Welcome, "
                                        + loggedInUser.getName()
                        );


                        // ADMIN LOGIN
                        if (loggedInUser instanceof Admin) {

                            adminMenu(
                                    scanner,
                                    infrastructureService,
                                    requestService,
                                    technicianService,
                                    trackingService
                            );
                        }


                        // TECHNICIAN LOGIN
                        else if (loggedInUser instanceof Technician) {

                            technicianMenu(
                                    scanner,
                                    (Technician) loggedInUser,
                                    requestService,
                                    trackingService
                            );
                        }


                        // NORMAL USER LOGIN
                        else {

                            userMenu(
                                    scanner,
                                    loggedInUser,
                                    requestService,
                                    trackingService
                            );
                        }

                    } catch (InvalidLoginException e) {

                        System.out.println(
                                "Login Failed: "
                                        + e.getMessage()
                        );
                    }

                    break;


                case "2":

                    try {

                        System.out.print("Enter User ID: ");

                        int id =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        System.out.print("Enter Name: ");
                        String name = scanner.nextLine();

                        System.out.print("Enter Username: ");
                        String newUsername = scanner.nextLine();

                        System.out.print("Enter Password: ");
                        String newPassword = scanner.nextLine();


                        auth.registerUser(
                                id,
                                name,
                                newUsername,
                                newPassword
                        );

                    } catch (NumberFormatException e) {

                        System.out.println(
                                "User ID must be a number."
                        );
                    }

                    break;


                case "3":

                    System.out.println(
                            "Thank you for using the system!"
                    );

                    scanner.close();

                    return;


                default:

                    System.out.println(
                            "Invalid choice!"
                    );
            }
        }
    }


    // ==========================================
    // ADMIN MENU
    // MODULE 2 TO MODULE 5
    // ==========================================

    public static void adminMenu(
            Scanner scanner,
            InfrastructureService infrastructureService,
            MaintenanceRequestService requestService,
            TechnicianService technicianService,
            MaintenanceTrackingService trackingService) {

        while (true) {

            System.out.println("\n========== ADMIN MENU ==========");

            System.out.println(
                    "\n----- MODULE 2: INFRASTRUCTURE -----"
            );

            System.out.println("1. Add Infrastructure");
            System.out.println("2. View Infrastructure");
            System.out.println("3. Search Infrastructure");
            System.out.println("4. Update Infrastructure");
            System.out.println("5. Delete Infrastructure");


            System.out.println(
                    "\n----- MODULE 3: MAINTENANCE REQUEST -----"
            );

            System.out.println("6. Create Maintenance Request");
            System.out.println("7. View All Maintenance Requests");


            System.out.println(
                    "\n----- MODULE 4: TECHNICIAN -----"
            );

            System.out.println("8. Add Technician");
            System.out.println("9. View Technicians");
            System.out.println("10. Assign Technician");


            System.out.println(
                    "\n----- MODULE 5: MAINTENANCE TRACKING -----"
            );

            System.out.println("11. Update Request Status");
            System.out.println("12. View Request Status");
            System.out.println("13. View Maintenance History");

            System.out.println("14. Logout");

            System.out.print("\nEnter your choice: ");

            String choice = scanner.nextLine();


            switch (choice) {

                // MODULE 2

                case "1":
                    infrastructureService.addInfrastructure();
                    break;

                case "2":
                    infrastructureService.viewInfrastructure();
                    break;

                case "3":
                    infrastructureService.searchInfrastructure();
                    break;

                case "4":
                    infrastructureService.updateInfrastructure();
                    break;

                case "5":
                    infrastructureService.deleteInfrastructure();
                    break;


                // MODULE 3

                case "6":

                    try {

                        System.out.print("Enter Request ID: ");

                        int requestId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        System.out.print(
                                "Enter Infrastructure ID: "
                        );

                        int infrastructureId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        System.out.print("Enter Problem: ");
                        String problem = scanner.nextLine();

                        System.out.print("Enter Priority: ");
                        String priority = scanner.nextLine();

                        System.out.print("Enter Reported By: ");
                        String reportedBy = scanner.nextLine();


                        requestService.createRequest(
                                requestId,
                                infrastructureId,
                                problem,
                                priority,
                                reportedBy
                        );

                    } catch (NumberFormatException e) {

                        System.out.println(
                                "Request ID and Infrastructure ID "
                                        + "must be numbers."
                        );
                    }

                    break;


                case "7":

                    requestService.viewAllRequests();

                    break;


                // MODULE 4

                case "8":

                    try {

                        System.out.print(
                                "Enter Technician ID: "
                        );

                        int technicianId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        System.out.print(
                                "Enter Technician Name: "
                        );

                        String technicianName =
                                scanner.nextLine();

                        System.out.print(
                                "Enter Username: "
                        );

                        String technicianUsername =
                                scanner.nextLine();

                        System.out.print(
                                "Enter Password: "
                        );

                        String technicianPassword =
                                scanner.nextLine();


                        technicianService.addTechnician(
                                technicianId,
                                technicianName,
                                technicianUsername,
                                technicianPassword
                        );

                    } catch (NumberFormatException e) {

                        System.out.println(
                                "Technician ID must be a number."
                        );
                    }

                    break;


                case "9":

                    technicianService.viewTechnicians();

                    break;


                case "10":

                    try {

                        System.out.print(
                                "Enter Maintenance Request ID: "
                        );

                        int requestId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        System.out.print(
                                "Enter Technician ID: "
                        );

                        int technicianId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );


                        technicianService.assignTechnician(
                                requestId,
                                technicianId,
                                requestService
                        );

                    } catch (NumberFormatException e) {

                        System.out.println(
                                "IDs must be numbers."
                        );
                    }

                    break;


                // MODULE 5

                case "11":

                    try {

                        System.out.print("Enter Request ID: ");

                        int requestId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        System.out.println("\nSelect Status:");
                        System.out.println("1. PENDING");
                        System.out.println("2. ASSIGNED");
                        System.out.println("3. IN_PROGRESS");
                        System.out.println("4. ON_HOLD");
                        System.out.println("5. COMPLETED");

                        System.out.print(
                                "Enter status choice: "
                        );

                        String statusChoice =
                                scanner.nextLine();

                        MaintenanceStatus newStatus = null;


                        switch (statusChoice) {

                            case "1":
                                newStatus =
                                        MaintenanceStatus.PENDING;
                                break;

                            case "2":
                                newStatus =
                                        MaintenanceStatus.ASSIGNED;
                                break;

                            case "3":
                                newStatus =
                                        MaintenanceStatus.IN_PROGRESS;
                                break;

                            case "4":
                                newStatus =
                                        MaintenanceStatus.ON_HOLD;
                                break;

                            case "5":
                                newStatus =
                                        MaintenanceStatus.COMPLETED;
                                break;

                            default:

                                System.out.println(
                                        "Invalid status choice!"
                                );
                        }


                        if (newStatus != null) {

                            trackingService.updateStatus(
                                    requestId,
                                    newStatus,
                                    requestService
                            );
                        }

                    } catch (NumberFormatException e) {

                        System.out.println(
                                "Request ID must be a number."
                        );
                    }

                    break;


                case "12":

                    try {

                        System.out.print("Enter Request ID: ");

                        int requestId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        trackingService.viewRequestStatus(
                                requestId,
                                requestService
                        );

                    } catch (NumberFormatException e) {

                        System.out.println(
                                "Request ID must be a number."
                        );
                    }

                    break;


                case "13":

                    trackingService.viewMaintenanceHistory();

                    break;


                case "14":

                    System.out.println(
                            "Logged out successfully."
                    );

                    return;


                default:

                    System.out.println(
                            "Invalid choice!"
                    );
            }
        }
    }


    // ==========================================
    // TECHNICIAN MENU
    // ==========================================

    public static void technicianMenu(
            Scanner scanner,
            Technician technician,
            MaintenanceRequestService requestService,
            MaintenanceTrackingService trackingService) {

        while (true) {

            technician.displayTechnicianMenu();

            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();


            switch (choice) {

                case "1":

                    requestService.viewAllRequests();

                    break;


                case "2":

                    try {

                        System.out.print(
                                "Enter Request ID: "
                        );

                        int requestId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        System.out.println(
                                "1. IN_PROGRESS"
                        );

                        System.out.println(
                                "2. ON_HOLD"
                        );

                        System.out.println(
                                "3. COMPLETED"
                        );

                        System.out.print(
                                "Choose Status: "
                        );

                        String statusChoice =
                                scanner.nextLine();

                        MaintenanceStatus status = null;


                        switch (statusChoice) {

                            case "1":

                                status =
                                        MaintenanceStatus.IN_PROGRESS;

                                break;

                            case "2":

                                status =
                                        MaintenanceStatus.ON_HOLD;

                                break;

                            case "3":

                                status =
                                        MaintenanceStatus.COMPLETED;

                                break;

                            default:

                                System.out.println(
                                        "Invalid status choice!"
                                );
                        }


                        if (status != null) {

                            trackingService.updateStatus(
                                    requestId,
                                    status,
                                    requestService
                            );
                        }

                    } catch (NumberFormatException e) {

                        System.out.println(
                                "Request ID must be a number."
                        );
                    }

                    break;


                case "3":

                    System.out.println(
                            "Logged out successfully."
                    );

                    return;


                default:

                    System.out.println(
                            "Invalid choice!"
                    );
            }
        }
    }


    // ==========================================
    // NORMAL USER MENU
    // ==========================================

    public static void userMenu(
            Scanner scanner,
            User user,
            MaintenanceRequestService requestService,
            MaintenanceTrackingService trackingService) {

        while (true) {

            System.out.println(
                    "\n========== USER MENU =========="
            );

            System.out.println(
                    "1. Create Maintenance Request"
            );

            System.out.println(
                    "2. View My Requests"
            );

            System.out.println(
                    "3. View Request Status"
            );

            System.out.println(
                    "4. Logout"
            );

            System.out.print(
                    "Enter your choice: "
            );

            String choice = scanner.nextLine();


            switch (choice) {

                case "1":

                    try {

                        System.out.print(
                                "Enter Request ID: "
                        );

                        int requestId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        System.out.print(
                                "Enter Infrastructure ID: "
                        );

                        int infrastructureId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        System.out.print(
                                "Enter Problem: "
                        );

                        String problem =
                                scanner.nextLine();

                        System.out.print(
                                "Enter Priority: "
                        );

                        String priority =
                                scanner.nextLine();


                        requestService.createRequest(
                                requestId,
                                infrastructureId,
                                problem,
                                priority,
                                user.getUsername()
                        );

                    } catch (NumberFormatException e) {

                        System.out.println(
                                "IDs must be numbers."
                        );
                    }

                    break;


                case "2":

                    requestService.viewUserRequests(
                            user.getUsername()
                    );

                    break;


                case "3":

                    try {

                        System.out.print(
                                "Enter Request ID: "
                        );

                        int requestId =
                                Integer.parseInt(
                                        scanner.nextLine()
                                );

                        trackingService.viewRequestStatus(
                                requestId,
                                requestService
                        );

                    } catch (NumberFormatException e) {

                        System.out.println(
                                "Request ID must be a number."
                        );
                    }

                    break;


                case "4":

                    System.out.println(
                            "Logged out successfully."
                    );

                    return;


                default:

                    System.out.println(
                            "Invalid choice!"
                    );
            }
        }
    }
}