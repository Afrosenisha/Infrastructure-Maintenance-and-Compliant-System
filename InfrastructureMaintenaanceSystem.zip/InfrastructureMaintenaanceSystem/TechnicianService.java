import java.util.ArrayList;

public class TechnicianService {

    private ArrayList<Technician> technicianList;

    public TechnicianService() {

        technicianList = new ArrayList<>();

        technicianList.add(
                new Technician(
                        2,
                        "Arun",
                        "technician",
                        "tech123"
                )
        );

        technicianList.add(
                new Technician(
                        4,
                        "Kumar",
                        "kumar",
                        "kumar123"
                )
        );
    }

    public void addTechnician(
            int id,
            String name,
            String username,
            String password) {

        Technician technician =
                new Technician(
                        id,
                        name,
                        username,
                        password
                );

        technicianList.add(technician);

        System.out.println(
                "Technician added successfully!"
        );
    }

    public void viewTechnicians() {

        System.out.println(
                "\n===== TECHNICIAN LIST ====="
        );

        for (Technician technician : technicianList) {

            System.out.println(
                    "ID       : "
                            + technician.getUserId()
            );

            System.out.println(
                    "Name     : "
                            + technician.getName()
            );

            System.out.println(
                    "Username : "
                            + technician.getUsername()
            );

            System.out.println("------------------------");
        }
    }

    public Technician findTechnician(int id)
            throws Exception {

        for (Technician technician : technicianList) {

            if (technician.getUserId() == id) {
                return technician;
            }
        }

        throw new Exception(
                "Technician not found."
        );
    }

    public void assignTechnician(
            int requestId,
            int technicianId,
            MaintenanceRequestService requestService) {

        try {

            MaintenanceRequest request =
                    requestService.findRequest(requestId);

            Technician technician =
                    findTechnician(technicianId);

            request.setAssignedTechnician(
                    technician.getName()
            );

            request.setStatus(
                    MaintenanceStatus.ASSIGNED
            );

            System.out.println(
                    "Technician "
                            + technician.getName()
                            + " assigned successfully!"
            );

        } catch (Exception e) {

            System.out.println(
                    "Error: " + e.getMessage()
            );
        }
    }

    public void viewAssignedTasks(
            String technicianName,
            MaintenanceRequestService requestService) {

        System.out.println(
                "Assigned tasks are available "
                        + "through the request service."
        );

        requestService.viewAllRequests();
    }
}