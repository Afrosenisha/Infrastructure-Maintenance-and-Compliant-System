public enum MaintenanceStatus {

    PENDING,
    ASSIGNED,
    IN_PROGRESS,
    ON_HOLD,
    COMPLETED
}