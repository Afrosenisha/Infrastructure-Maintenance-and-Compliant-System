import java.util.ArrayList;

public class MaintenanceRequestService {

    private ArrayList<MaintenanceRequest> requestList;
    private DatabaseService databaseService;

    public MaintenanceRequestService() {
        requestList = new ArrayList<>();
        databaseService = new DatabaseService();
    }

    public void createRequest(
            int requestId,
            int infrastructureId,
            String problem,
            String priority,
            String reportedBy) {

        for (MaintenanceRequest request : requestList) {

            if (request.getRequestId() == requestId) {

                System.out.println(
                        "Request ID already exists!"
                );
                return;
            }
        }

        MaintenanceRequest request =
                new MaintenanceRequest(
                        requestId,
                        infrastructureId,
                        problem,
                        priority,
                        reportedBy
                );

        requestList.add(request);
        databaseService.saveMaintenanceRequest(request);

        System.out.println(
                "Maintenance request created successfully!"
        );
    }

    public MaintenanceRequest findRequest(int requestId)
            throws RequestNotFoundException {

        for (MaintenanceRequest request : requestList) {

            if (request.getRequestId() == requestId) {
                return request;
            }
        }

        throw new RequestNotFoundException(
                "Maintenance Request ID "
                        + requestId
                        + " not found."
        );
    }

    public void viewAllRequests() {

        if (requestList.isEmpty()) {

            System.out.println(
                    "No maintenance requests found."
            );
            return;
        }

        System.out.println(
                "\n===== ALL MAINTENANCE REQUESTS ====="
        );

        for (MaintenanceRequest request : requestList) {
            request.displayRequest();
        }
    }

    public void viewUserRequests(String username) {

        boolean found = false;

        System.out.println(
                "\n===== MY MAINTENANCE REQUESTS ====="
        );

        for (MaintenanceRequest request : requestList) {

            if (request.getReportedBy().equalsIgnoreCase(username)) {

                request.displayRequest();
                found = true;
            }
        }

        if (!found) {
            System.out.println(
                    "No requests found for this user."
            );
        }
    }
}


    