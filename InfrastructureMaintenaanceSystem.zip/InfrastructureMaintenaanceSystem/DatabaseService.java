import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseService {

    public void saveMaintenanceRequest(
            MaintenanceRequest request) {

        String sql =
                "INSERT INTO maintenance_requests "
                        + "(request_id, infrastructure_id, "
                        + "problem, priority, reported_by, "
                        + "assigned_technician, status, "
                        + "request_date) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    request.getRequestId()
            );

            statement.setInt(
                    2,
                    request.getInfrastructureId()
            );

            statement.setString(
                    3,
                    request.getProblem()
            );

            statement.setString(
                    4,
                    request.getPriority()
            );

            statement.setString(
                    5,
                    request.getReportedBy()
            );

            statement.setString(
                    6,
                    request.getAssignedTechnician()
            );

            statement.setString(
                    7,
                    request.getStatus().toString()
            );

            statement.setTimestamp(
                    8,
                    java.sql.Timestamp.valueOf(
                            request.getRequestDate()
                    )
            );

            statement.executeUpdate();

            System.out.println(
                    "Request saved to database successfully!"
            );

        } catch (SQLException e) {

            System.out.println(
                    "Database Error: "
                            + e.getMessage()
            );
        }
    }

    public void generateRequestReport() {

        String sql =
                "SELECT * FROM maintenance_requests";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            System.out.println(
                    "\n===== MAINTENANCE REPORT ====="
            );

            while (resultSet.next()) {

                System.out.println(
                        "\nRequest ID: "
                                + resultSet.getInt(
                                        "request_id"
                                )
                );

                System.out.println(
                        "Infrastructure ID: "
                                + resultSet.getInt(
                                        "infrastructure_id"
                                )
                );

                System.out.println(
                        "Problem: "
                                + resultSet.getString(
                                        "problem"
                                )
                );

                System.out.println(
                        "Priority: "
                                + resultSet.getString(
                                        "priority"
                                )
                );

                System.out.println(
                        "Status: "
                                + resultSet.getString(
                                        "status"
                                )
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Database Error: "
                            + e.getMessage()
            );
        }
    }
}