import java.util.ArrayList;
import java.util.Scanner;

public class InfrastructureService
        implements MaintenanceOperations {

    private ArrayList<Infrastructure> infrastructureList;
    private Scanner scanner;

    public InfrastructureService() {

        infrastructureList = new ArrayList<>();
        scanner = new Scanner(System.in);

        // Sample infrastructure
        infrastructureList.add(
            new Infrastructure(
                101,
                "Computer Lab 1",
                "Block A",
                "Laboratory",
                "Good"
            )
        );

        infrastructureList.add(
            new Infrastructure(
                102,
                "Projector",
                "Seminar Hall",
                "Equipment",
                "Needs Maintenance"
            )
        );
    }

    @Override
    public void addInfrastructure() {

        try {

            System.out.println("\n===== ADD INFRASTRUCTURE =====");

            System.out.print("Enter ID: ");
            int id = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Location: ");
            String location = scanner.nextLine();

            System.out.print("Enter Type: ");
            String type = scanner.nextLine();

            System.out.print("Enter Condition: ");
            String condition = scanner.nextLine();

            Infrastructure infrastructure =
                    new Infrastructure(
                            id,
                            name,
                            location,
                            type,
                            condition
                    );

            infrastructureList.add(infrastructure);

            System.out.println(
                    "Infrastructure added successfully!"
            );

        } catch (NumberFormatException e) {

            System.out.println(
                    "Error: ID must be a number."
            );
        }
    }

    @Override
    public void viewInfrastructure() {

        System.out.println(
                "\n===== INFRASTRUCTURE LIST ====="
        );

        if (infrastructureList.isEmpty()) {

            System.out.println(
                    "No infrastructure found."
            );

            return;
        }

        for (Infrastructure infrastructure
                : infrastructureList) {

            infrastructure.displayInfrastructure();
        }
    }

    @Override
    public void searchInfrastructure() {

        try {

            System.out.print(
                    "\nEnter Infrastructure ID: "
            );

            int id =
                    Integer.parseInt(scanner.nextLine());

            boolean found = false;

            for (Infrastructure infrastructure
                    : infrastructureList) {

                if (infrastructure.getId() == id) {

                    infrastructure.displayInfrastructure();
                    found = true;
                    break;
                }
            }

            if (!found) {

                System.out.println(
                        "Infrastructure not found."
                );
            }

        } catch (NumberFormatException e) {

            System.out.println(
                    "Please enter a valid ID."
            );
        }
    }

    @Override
    public void updateInfrastructure() {

        try {

            System.out.print(
                    "\nEnter Infrastructure ID: "
            );

            int id =
                    Integer.parseInt(scanner.nextLine());

            for (Infrastructure infrastructure
                    : infrastructureList) {

                if (infrastructure.getId() == id) {

                    System.out.print(
                            "Enter New Name: "
                    );
                    infrastructure.setName(
                            scanner.nextLine()
                    );

                    System.out.print(
                            "Enter New Location: "
                    );
                    infrastructure.setLocation(
                            scanner.nextLine()
                    );

                    System.out.print(
                            "Enter New Type: "
                    );
                    infrastructure.setType(
                            scanner.nextLine()
                    );

                    System.out.print(
                            "Enter New Condition: "
                    );
                    infrastructure.setCondition(
                            scanner.nextLine()
                    );

                    System.out.println(
                            "Infrastructure updated successfully!"
                    );

                    return;
                }
            }

            System.out.println(
                    "Infrastructure ID not found."
            );

        } catch (NumberFormatException e) {

            System.out.println(
                    "Invalid ID."
            );
        }
    }

    @Override
    public void deleteInfrastructure() {

        try {

            System.out.print(
                    "\nEnter Infrastructure ID: "
            );

            int id =
                    Integer.parseInt(scanner.nextLine());

            for (Infrastructure infrastructure
                    : infrastructureList) {

                if (infrastructure.getId() == id) {

                    infrastructureList.remove(
                            infrastructure
                    );

                    System.out.println(
                            "Infrastructure deleted successfully!"
                    );

                    return;
                }
            }

            System.out.println(
                    "Infrastructure not found."
            );

        } catch (NumberFormatException e) {

            System.out.println(
                    "Invalid ID."
            );
        }
    }
}