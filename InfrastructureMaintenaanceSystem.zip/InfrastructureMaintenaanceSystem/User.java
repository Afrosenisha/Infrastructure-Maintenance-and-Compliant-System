public class User {
    protected int userId;
    protected String name;
    protected String username;
    protected String password;

    public User(int userId, String name, String username, String password) {
        this.userId = userId;
        this.name = name;
        this.username = username;
        this.password = password;
    }

    public int getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public boolean checkPassword(String password) {
        return this.password.equals(password);
    }

    public void displayUser() {
        System.out.println("User ID  : " + userId);
        System.out.println("Name     : " + name);
        System.out.println("Username : " + username);
    }
}
