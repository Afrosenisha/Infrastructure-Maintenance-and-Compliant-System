public class Infrastructure {

    private int id;
    private String name;
    private String location;
    private String type;
    private String condition;

    public Infrastructure(
            int id,
            String name,
            String location,
            String type,
            String condition) {

        this.id = id;
        this.name = name;
        this.location = location;
        this.type = type;
        this.condition = condition;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getType() {
        return type;
    }

    public String getCondition() {
        return condition;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public void displayInfrastructure() {

        System.out.println("--------------------------------");
        System.out.println("Infrastructure ID : " + id);
        System.out.println("Name              : " + name);
        System.out.println("Location          : " + location);
        System.out.println("Type              : " + type);
        System.out.println("Condition         : " + condition);
    }
}