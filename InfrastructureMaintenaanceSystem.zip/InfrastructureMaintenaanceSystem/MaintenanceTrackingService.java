import java.util.ArrayList;

public class MaintenanceTrackingService {

    private ArrayList<MaintenanceHistory> historyList;

    public MaintenanceTrackingService() {
        historyList = new ArrayList<>();
    }

    public void updateStatus(
            int requestId,
            MaintenanceStatus newStatus,
            MaintenanceRequestService requestService) {

        try {

            MaintenanceRequest request =
                    requestService.findRequest(requestId);

            request.setStatus(newStatus);

            System.out.println(
                    "Status updated successfully to: "
                            + newStatus
            );

            if (newStatus == MaintenanceStatus.COMPLETED) {

                MaintenanceHistory history =
                        new MaintenanceHistory(
                                request.getRequestId(),
                                "Infrastructure ID: "
                                        + request.getInfrastructureId(),
                                request.getProblem(),
                                request.getAssignedTechnician()
                        );

                historyList.add(history);

                System.out.println(
                        "Maintenance history created."
                );
            }

        } catch (RequestNotFoundException e) {

            System.out.println(
                    "Error: " + e.getMessage()
            );
        }
    }

    public void viewRequestStatus(
            int requestId,
            MaintenanceRequestService requestService) {

        try {

            MaintenanceRequest request =
                    requestService.findRequest(requestId);

            System.out.println(
                    "\n===== REQUEST STATUS ====="
            );

            System.out.println(
                    "Request ID : "
                            + request.getRequestId()
            );

            System.out.println(
                    "Status     : "
                            + request.getStatus()
            );

            System.out.println(
                    "Technician : "
                            + request.getAssignedTechnician()
            );

        } catch (RequestNotFoundException e) {

            System.out.println(
                    "Error: " + e.getMessage()
            );
        }
    }

    public void viewMaintenanceHistory() {

        if (historyList.isEmpty()) {

            System.out.println(
                    "No completed maintenance history."
            );

            return;
        }

        for (MaintenanceHistory history : historyList) {
            history.displayHistory();
        }
    }
}