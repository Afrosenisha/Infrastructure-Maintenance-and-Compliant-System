import java.time.LocalDateTime;

public class MaintenanceRequest {

    private int requestId;
    private int infrastructureId;
    private String problem;
    private String priority;
    private String reportedBy;
    private String assignedTechnician;
    private MaintenanceStatus status;
    private LocalDateTime requestDate;
    private LocalDateTime completedDate;

    public MaintenanceRequest(
            int requestId,
            int infrastructureId,
            String problem,
            String priority,
            String reportedBy) {

        this.requestId = requestId;
        this.infrastructureId = infrastructureId;
        this.problem = problem;
        this.priority = priority;
        this.reportedBy = reportedBy;
        this.assignedTechnician = "Not Assigned";
        this.status = MaintenanceStatus.PENDING;
        this.requestDate = LocalDateTime.now();
    }

    public int getRequestId() {
        return requestId;
    }

    public int getInfrastructureId() {
        return infrastructureId;
    }

    public String getProblem() {
        return problem;
    }

    public String getPriority() {
        return priority;
    }

    public String getReportedBy() {
        return reportedBy;
    }

    public String getAssignedTechnician() {
        return assignedTechnician;
    }

    public MaintenanceStatus getStatus() {
        return status;
    }

    public LocalDateTime getRequestDate() {
        return requestDate;
    }

    public LocalDateTime getCompletedDate() {
        return completedDate;
    }

    public void setAssignedTechnician(String assignedTechnician) {
        this.assignedTechnician = assignedTechnician;
    }

    public void setStatus(MaintenanceStatus status) {
        this.status = status;

        if (status == MaintenanceStatus.COMPLETED) {
            completedDate = LocalDateTime.now();
        }
    }

    public void displayRequest() {

        System.out.println("\n--------------------------------");
        System.out.println("Request ID       : " + requestId);
        System.out.println("Infrastructure ID: " + infrastructureId);
        System.out.println("Problem          : " + problem);
        System.out.println("Priority         : " + priority);
        System.out.println("Reported By      : " + reportedBy);
        System.out.println("Technician       : " + assignedTechnician);
        System.out.println("Status           : " + status);
        System.out.println("Request Date     : " + requestDate);

        if (completedDate != null) {
            System.out.println("Completed Date   : " + completedDate);
        }
    }
}