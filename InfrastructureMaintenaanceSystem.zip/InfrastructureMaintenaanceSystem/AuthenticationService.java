import java.util.ArrayList;

public class AuthenticationService {

    private ArrayList<User> users;

    public AuthenticationService() {

        users = new ArrayList<>();

        // Default Admin
        users.add(
            new Admin(
                1,
                "System Admin",
                "admin",
                "admin123"
            )
        );

        // Default Technician
        users.add(
            new Technician(
                2,
                "Arun",
                "technician",
                "tech123"
            )
        );

        // Default User
        users.add(
            new User(
                3,
                "Student",
                "student",
                "student123"
            )
        );
    }

    public void registerUser(
            int id,
            String name,
            String username,
            String password) {

        for (User user : users) {

            if (user.getUsername().equalsIgnoreCase(username)) {
                System.out.println("Username already exists!");
                return;
            }
        }

        User newUser =
                new User(id, name, username, password);

        users.add(newUser);

        System.out.println("Registration successful!");
    }

    public User login(
            String username,
            String password)
            throws InvalidLoginException {

        for (User user : users) {

            if (user.getUsername().equals(username)
                    && user.checkPassword(password)) {

                return user;
            }
        }

        throw new InvalidLoginException(
                "Invalid username or password!"
        );
    }
}