public interface MaintenanceOperations {

    void addInfrastructure();

    void viewInfrastructure();

    void searchInfrastructure();

    void updateInfrastructure();

    void deleteInfrastructure();
}