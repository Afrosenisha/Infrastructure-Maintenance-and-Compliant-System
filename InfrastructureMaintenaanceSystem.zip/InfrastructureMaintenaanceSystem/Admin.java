public class Admin extends User {

    public Admin(
            int userId,
            String name,
            String username,
            String password) {

        super(
                userId,
                name,
                username,
                password
        );
    }

    public void displayAdminMenu() {

        System.out.println(
                "\n========== ADMIN MENU =========="
        );

        // MODULE 2
        System.out.println(
                "\n----- MODULE 2: INFRASTRUCTURE -----"
        );
        System.out.println(
                "1. Add Infrastructure"
        );
        System.out.println(
                "2. View Infrastructure"
        );
        System.out.println(
                "3. Search Infrastructure"
        );
        System.out.println(
                "4. Update Infrastructure"
        );
        System.out.println(
                "5. Delete Infrastructure"
        );


        // MODULE 3
        System.out.println(
                "\n----- MODULE 3: MAINTENANCE REQUEST -----"
        );
        System.out.println(
                "6. Create Maintenance Request"
        );
        System.out.println(
                "7. View All Maintenance Requests"
        );


        // MODULE 4
        System.out.println(
                "\n----- MODULE 4: TECHNICIAN MANAGEMENT -----"
        );
        System.out.println(
                "8. Add Technician"
        );
        System.out.println(
                "9. View Technicians"
        );
        System.out.println(
                "10. Assign Technician"
        );


        // MODULE 5
        System.out.println(
                "\n----- MODULE 5: MAINTENANCE TRACKING -----"
        );
        System.out.println(
                "11. Update Request Status"
        );
        System.out.println(
                "12. View Request Status"
        );
        System.out.println(
                "13. View Maintenance History"
        );


        // LOGOUT
        System.out.println(
                "\n14. Logout"
        );

        System.out.println(
                "================================"
        );
    }
}