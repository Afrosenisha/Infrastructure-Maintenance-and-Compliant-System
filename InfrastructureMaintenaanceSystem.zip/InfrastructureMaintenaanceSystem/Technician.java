public class Technician extends User {

    public Technician(int userId, String name, String username, String password) {
        super(userId, name, username, password);
    }

    public void displayTechnicianMenu() {
        System.out.println("\n======= TECHNICIAN MENU =======");
        System.out.println("1. View Assigned Tasks");
        System.out.println("2. Update Maintenance Status");
        System.out.println("3. Logout");
        System.out.println("===============================");
    }
}