import java.time.LocalDateTime;

public class MaintenanceHistory {

    private int requestId;
    private String infrastructureDetails;
    private String problem;
    private String technician;
    private LocalDateTime completedDate;

    public MaintenanceHistory(
            int requestId,
            String infrastructureDetails,
            String problem,
            String technician) {

        this.requestId = requestId;
        this.infrastructureDetails = infrastructureDetails;
        this.problem = problem;
        this.technician = technician;
        this.completedDate = LocalDateTime.now();
    }

    public void displayHistory() {

        System.out.println("\n===== MAINTENANCE HISTORY =====");

        System.out.println(
                "Request ID       : " + requestId
        );

        System.out.println(
                "Infrastructure   : "
                        + infrastructureDetails
        );

        System.out.println(
                "Problem          : " + problem
        );

        System.out.println(
                "Technician       : " + technician
        );

        System.out.println(
                "Completed Date   : "
                        + completedDate
        );

        System.out.println(
                "Status           : COMPLETED"
        );
    }
}